package com.example.demo.model;

public class User {
    private Long id;
    private String name;
    private String email;

    // Getters and Setters
}