package com.example.demo.service;

import com.example.demo.mapper.ExampleMapper;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;

@Service
public class ExcelExportService {

    private final ExampleMapper exampleMapper;

    public ExcelExportService(ExampleMapper exampleMapper) {
        this.exampleMapper = exampleMapper;
    }

    public void exportToExcel(String path) throws Exception {
        List<Map<String, Object>> users = exampleMapper.queryUsers();
        List<Map<String, Object>> orders = exampleMapper.queryOrders();
        List<Map<String, Object>> products = exampleMapper.queryProducts();

        try (Workbook workbook = new XSSFWorkbook()) {
            writeSheet(workbook, "Users", users);
            writeSheet(workbook, "Orders", orders);
            writeSheet(workbook, "Products", products);

            try (FileOutputStream fos = new FileOutputStream(path)) {
                workbook.write(fos);
            }
        }
    }

    private void writeSheet(Workbook workbook, String name, List<Map<String, Object>> data) {
        Sheet sheet = workbook.createSheet(name);
        if (data.isEmpty()) return;

        Row header = sheet.createRow(0);
        int col = 0;
        for (String key : data.get(0).keySet()) {
            header.createCell(col++).setCellValue(key);
        }

        int rowNum = 1;
        for (Map<String, Object> rowData : data) {
            Row row = sheet.createRow(rowNum++);
            col = 0;
            for (String key : rowData.keySet()) {
                Object value = rowData.get(key);
                row.createCell(col++).setCellValue(value != null ? value.toString() : "");
            }
        }
    }
}