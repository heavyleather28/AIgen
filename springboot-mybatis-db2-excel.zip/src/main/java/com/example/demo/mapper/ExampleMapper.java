package com.example.demo.mapper;

import org.apache.ibatis.annotations.Mapper;
import java.util.List;
import java.util.Map;

@Mapper
public interface ExampleMapper {
    List<Map<String, Object>> queryUsers();
    List<Map<String, Object>> queryOrders();
    List<Map<String, Object>> queryProducts();
}